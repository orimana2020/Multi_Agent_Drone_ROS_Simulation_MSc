

try:
    x,y,z = None
    print(1)
except:
    print(2)