import numpy as np

print(np.random.random(1) * 2*np.pi)