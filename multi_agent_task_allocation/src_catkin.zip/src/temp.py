import params
current_drone_num = 2
tadrone_num = 4
for j in range(tadrone_num-1, current_drone_num-1,-1):
    print(j)