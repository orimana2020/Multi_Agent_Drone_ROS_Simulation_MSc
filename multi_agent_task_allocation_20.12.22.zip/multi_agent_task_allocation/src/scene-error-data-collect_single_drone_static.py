#! /usr/bin/env python3
import numpy as np
import params
import time
"""
how to use:
1. set is_reach_goal to 0.015 in cf mode
"""
if params.mode == 'sim':
    from rotors_flight_manager import Flight_manager
    import rospy
    rospy.init_node('send_my_command', anonymous=True)
    rospy.sleep(3)
elif params.mode == 'cf':
    from CF_Flight_Manager import Flight_manager

samples_num = 1000



def main():
    fc = Flight_manager(1)
    pos_data = []
    for _ in range(samples_num):
        pos_data.append(fc.get_position(drone_idx=0))

    pos_data = np.array(pos_data)   
    
    print(f'average position = {np.average(pos_data, axis=0)}') 
    
    np.save('static_pos_1', pos_data)
                
if __name__ == '__main__':
    main()

